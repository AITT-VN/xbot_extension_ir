# xbot_extension_ir
Mục mở rộng của xBot để làm việc với thu phát hồng ngoại
